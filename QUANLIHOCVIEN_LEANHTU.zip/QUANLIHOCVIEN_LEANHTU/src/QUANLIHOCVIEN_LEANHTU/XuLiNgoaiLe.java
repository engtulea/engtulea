package QUANLIHOCVIEN_LEANHTU;

public class XuLiNgoaiLe extends Exception{
public XuLiNgoaiLe(String message){
	super(message);
}
}

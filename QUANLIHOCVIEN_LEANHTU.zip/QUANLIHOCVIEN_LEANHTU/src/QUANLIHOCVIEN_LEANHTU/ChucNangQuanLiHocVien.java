package QUANLIHOCVIEN_LEANHTU;

import java.util.*;
import java.awt.SystemColor;
import java.io.*;
import java.nio.BufferUnderflowException;

public class ChucNangQuanLiHocVien {
	int n = 0;
	int[] maSo = null;
	String[] tenHV = null;
	String[] ngaySinh = null;
	String[] email = null;
	String[] soDienThoai = null;
	String[] diaChi = null;
	Scanner scan2 = new Scanner(System.in);
	Scanner scan3 = new Scanner(System.in);
	Scanner chooseFind = new Scanner(System.in);

	// Phương thức xem danh sách học viên
	public void xemHocVien() {

		// đọc danh sách từ tệp
		try {
			FileReader fileReader = new FileReader("C:/QUANLIHOCVIEN.txt");

			BufferedReader br = new BufferedReader(fileReader);

			String s = "";

			try {
				s = br.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// Xuất ra các thông tin từ chuỗi s trong tệp
			int count = 0;
			int soKiTu$ = 0;

			StringBuilder chuoi = new StringBuilder();
			if (s == null) {
				System.out.println("Danh sách hiện đang trống !!!");
			} else {

				while (count < s.length()) {

					if (s.charAt(count) != '$') {
						chuoi.append(s.charAt(count));
						count += 1;
					} else {
						soKiTu$ += 1;
						switch (soKiTu$) {
						case 1:
							System.out.print("\nMã số " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;
						case 2:
							System.out.print("\nTên học viên: " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;
						case 3:
							System.out.print("\nNgày sinh: " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;
						case 4:
							System.out.print("\nEmail: " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;
						case 5:
							System.out.print("\nSố điện thoại: " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;

						case 6:
							System.out.println("\nđịa chỉ: " + chuoi);
							chuoi.delete(0, chuoi.length());
							soKiTu$ = 0;
							break;
						default:
							System.out.println("Bạn đã nhập không đúng chức năng của ứng dụng !!!");
							break;
						}

						count += 1;
					}

				}
			}
			System.out.println(chuoi);

			try {
				fileReader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Danh sách hiện đang trống !!!");
		}

	}

	// Phương thức nhập thông tin học viên
	public void themHocVien() {

		System.out.print("Vui lòng cho biết số lượng học viên cần nhập vào: ");
		n = scan2.nextInt();

		// Tạo vùng nhớ cho mảng
		tenHV = new String[n];
		maSo = new int[n];
		ngaySinh = new String[n];
		email = new String[n];
		soDienThoai = new String[n];
		diaChi = new String[n];

		// Nhập thông tin cho từng học viên
		Random rd = new Random();
		int ranDom;
		ranDom = rd.nextInt(1000);
		KiemTraNgoaiLe kiemtra = new KiemTraNgoaiLe();

		int i = 0;
		while (i < n) {

			maSo[i] = (ranDom + i);
			System.out.print("\nTên học viên " + (i + 1) + " : ");
			tenHV[i] = scan3.nextLine();
			int lap = 1;
			while (lap == 1) {
				System.out.print("Ngày sinh: ");
				ngaySinh[i] = scan3.nextLine();

				lap = 0;
				try {
					kiemtra.checkNgaySinh(ngaySinh[i]);
				} catch (XuLiNgoaiLe e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
					lap = 1;
				}

			}

			lap = 1;
			while (lap == 1) {

				System.out.print("Email: ");
				email[i] = scan3.nextLine();
				lap = 0;
				try {
					kiemtra.checkEmail(email[i]);
				} catch (XuLiNgoaiLe e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
					lap = 1;
				}

			}

			lap = 1;

			while (lap == 1) {

				System.out.print("Số điện thoại: ");
				soDienThoai[i] = scan3.nextLine();
				lap = 0;
				try {
					kiemtra.checkSDT(soDienThoai[i]);
				} catch (XuLiNgoaiLe e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
					lap = 1;
				}

			}

			System.out.print("địa chỉ: ");
			diaChi[i] = scan3.nextLine();
			i += 1;
		}

		// Tạo chuỗi để ghi lên tệp
		String s = "";

		i = 0;
		while (i < n) {
			s = s + "#" + maSo[i] + "$" + tenHV[i] + "$" + ngaySinh[i] + "$" + email[i] + "$" + soDienThoai[i] + "$"
					+ diaChi[i] + "$";
			i += 1;
		}

		// Ghi danh sách học viên vừa nhập lên tệp
		try {
			FileWriter fileWriter = new FileWriter("C:/QUANLIHOCVIEN.txt");

			fileWriter.write(s);

			fileWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void timKiem() {
		String tuKhoa = "";
		String choose = null;

		System.out.println("<1: Tìm kiếm theo mã số học viên>");
		System.out.println("<2: Tìm kiếm theo tên học viên>");
		System.out.println("<3: Tìm kiếm theo từ khoá>");
		System.out.print("Chọn chức năng tìm kiếm: ");
		choose = chooseFind.nextLine();

		String s = "";
		try {
			FileReader fileReader = new FileReader("C:/QUANLIHOCVIEN.txt");
			BufferedReader br = new BufferedReader(fileReader);

			try {
				s = br.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Danh sách hiện đang trống !!!");
			}

			try {
				fileReader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Danh sách hiện đang trống !!!");
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Danh sách hiện đang trống !!!");
		}
		if (s == null) {
			s = "";
		} else {
			s = s;
		}

		switch (choose) {
		case "1":

			int find = 0;

			System.out.print("Nhập mã số học viên cần tìm: #");
			tuKhoa = scan3.nextLine();
			tuKhoa = "#" + tuKhoa;

			find = s.indexOf(tuKhoa);

			if (find == -1) {
				System.out.println("Không tìm thấy mã số học viên cần tìm !!!");

			} else {

				// In ra thông tin học viên có mã số cần tìm

				int soKiTu$ = 0;

				StringBuilder chuoi = new StringBuilder();
				while (soKiTu$ < 6) {

					if (s.charAt(find) != '$') {
						chuoi.append(s.charAt(find));

						find += 1;
					} else {
						soKiTu$ += 1;

						find += 1;
						switch (soKiTu$) {
						case 1:
							System.out.print("\nMã số " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;
						case 2:
							System.out.print("\nTên học viên: " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;
						case 3:
							System.out.print("\nNgày sinh: " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;
						case 4:
							System.out.print("\nEmail: " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;
						case 5:
							System.out.print("\nSố điện thoại: " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;
						}
					}
				}
				System.out.println("\nđịa chỉ: " + chuoi);
				chuoi.delete(0, chuoi.length());
				// Kết thúc in thông tin học viên đó
			}
			break;

		case "2":

			find = 0;

			System.out.print("Nhập tên học viên cần tìm: ");
			tuKhoa = scan3.nextLine();
			tuKhoa = tuKhoa;
			find = s.indexOf(tuKhoa);
			if (find == -1) {
				System.out.println("Không tìm thấy học viên có tên cần tìm !!!");

			} else {

				// In ra thông tin học viên có mã số cần tìm

				while (s.charAt(find) != '#') {
					find = find - 1;
				}

				int soKiTu$ = 0;

				StringBuilder chuoi = new StringBuilder();
				while (soKiTu$ < 6) {

					if (s.charAt(find) != '$') {
						chuoi.append(s.charAt(find));

						find += 1;
					} else {
						soKiTu$ += 1;

						find += 1;
						switch (soKiTu$) {
						case 1:
							System.out.print("\nMã số " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;
						case 2:
							System.out.print("\nTên học viên: " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;
						case 3:
							System.out.print("\nNgày sinh: " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;
						case 4:
							System.out.print("\nEmail: " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;
						case 5:
							System.out.print("\nSố điện thoại: " + chuoi);
							chuoi.delete(0, chuoi.length());
							break;
						}
					}
				}
				System.out.println("\nđịa chỉ: " + chuoi);
				chuoi.delete(0, chuoi.length());
				// Kết thúc in thông tin học viên đó
			}

			break;

		case "3":
			find = 0;

			System.out.print("Nhập từ khoá cần tìm: ");
			tuKhoa = scan3.nextLine();
			tuKhoa = tuKhoa;
			find = s.indexOf(tuKhoa);
			if (find == -1) {
				System.out.println("Không tìm thấy thông tin học viên có từ khoá cần tìm !!!");

			} else {

				// In ra thông tin học viên có mã số cần tìm
				while (find != -1) {

					while (s.charAt(find) != '#')
						find = find - 1;

					int soKiTu$ = 0;

					StringBuilder chuoi = new StringBuilder();
					while (soKiTu$ < 6) {

						if (s.charAt(find) != '$') {
							chuoi.append(s.charAt(find));

							find += 1;
						} else {
							soKiTu$ += 1;

							find += 1;
							switch (soKiTu$) {
							case 1:
								System.out.print("\nMã số " + chuoi);
								chuoi.delete(0, chuoi.length());
								break;
							case 2:
								System.out.print("\nTên học viên: " + chuoi);
								chuoi.delete(0, chuoi.length());
								break;
							case 3:
								System.out.print("\nNgày sinh: " + chuoi);
								chuoi.delete(0, chuoi.length());
								break;
							case 4:
								System.out.print("\nEmail: " + chuoi);
								chuoi.delete(0, chuoi.length());
								break;
							case 5:
								System.out.print("\nSố điện thoại: " + chuoi);
								chuoi.delete(0, chuoi.length());
								break;
							}
						}
					}
					System.out.println("\nđịa chỉ: " + chuoi);
					chuoi.delete(0, chuoi.length());
					// Kết thúc in thông tin học viên đó

					s = s.substring(find);
					find = s.indexOf(tuKhoa);
				}

			}

			break;

		default:
			System.out.println("Bạn đã nhập không đúng chức năng của ứng dụng !!!");
			break;
		}

	}

	public void xoaHocVien() {
		String tuKhoa = "";
		String choose = null;
		int find = 0;
		String s1 = "";
		String s2 = "";

		System.out.println("<0>: Xoá tất cả học viên trong danh sách");
		System.out.println("<1>: Xoá học viên theo mã số");
		System.out.print("Chọn chức năng xoá: ");
		choose = chooseFind.nextLine();

		String s = "";
		try {
			FileReader fileReader = new FileReader("C:/QUANLIHOCVIEN.txt");
			BufferedReader br = new BufferedReader(fileReader);

			try {
				s = br.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Danh sách hiện đang trống !!!");
			}

			try {
				fileReader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Danh sách hiện đang trống !!!");
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Danh sách hiện đang trống !!!");
		}

		switch (choose) {
		case "0":

			// String del = "#<none>$<none>$<none>$<none>$<none>$<none>$";
			String del = "";
			try {
				FileWriter fileWriter = new FileWriter("C:/QUANLIHOCVIEN.txt");

				fileWriter.write(del);

				fileWriter.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Danh sách hiện đang trống !!!");
			}
			System.out.println("\nĐÃ XOÁ THÀNH CÔNG !!!");

			break;
		case "1":
			System.out.print("Nhập mã số học viên cần xoá: #");

			tuKhoa = scan3.nextLine();
			tuKhoa = "#" + tuKhoa;
try {
	find = s.indexOf(tuKhoa);
} catch (Exception e) {
	System.out.println("Danh sách hiện đang trống !!!");
}
			
			
			// Xoá học viên theo mã số
			if (find == -1) {
				System.out.println("Không tìm thấy mã số học viên cần xoá !!!");

			} else {
				s1 = s.substring(0, find);
				// In ra thông tin học viên có mã số cần tìm

				int soKiTu$ = 0;

				StringBuilder chuoi = new StringBuilder();
				while (soKiTu$ < 6) {

					if (s.charAt(find) != '$') {
						chuoi.append(s.charAt(find));

						find += 1;
					} else {
						soKiTu$ += 1;

						find += 1;

					}

				}
				s2 = s.substring(find);

				s = s1 + s2;

				try {
					FileWriter fileWriter = new FileWriter("C:/QUANLIHOCVIEN.txt");

					fileWriter.write(s);

					fileWriter.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("\nĐÃ XOÁ THÀNH CÔNG !!!");

			}
			break;

		default:
			System.out.println("Bạn đã nhập không đúng chức năng của ứng dụng !!!");
			break;
		}

	}

	public void capNhat() {
		String choose = null;
		System.out.println("<0>: Cập nhật thêm vào danh sách hiện tại");
		System.out.println("<1>: Thay đổi thông tin học viên hiện tại");
		System.out.print("Chọn chức năng cập nhật: ");
		choose = chooseFind.nextLine();

		String s = "";
		try {
			FileReader fileReader = new FileReader("C:/QUANLIHOCVIEN.txt");

			BufferedReader br = new BufferedReader(fileReader);

			try {
				s = br.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				fileReader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.print("Danh sách hiện đang trống !!!");
		}
		if (s == null) {
			s = "";
		} else {
			s = s;
		}

		switch (choose) {
		case "0":

			Random rd = new Random();
			int ranDom;
			ranDom = rd.nextInt(1000);

			System.out.print("Vui lòng cho biết số lượng học viên cần nhập thêm vào danh sách: ");
			n = scan2.nextInt();

			// Tạo vùng nhớ cho mảng
			tenHV = new String[n];
			maSo = new int[n];
			ngaySinh = new String[n];
			email = new String[n];
			soDienThoai = new String[n];
			diaChi = new String[n];

			// Nhập thông tin cho từng học viên
			int i = 0;
			KiemTraNgoaiLe kiemtra = new KiemTraNgoaiLe();
			while (i < n) {

				maSo[i] = (ranDom + i);
				System.out.print("\nTên học viên " + (i + 1) + " : ");
				tenHV[i] = scan3.nextLine();
				int lap = 1;
				while (lap == 1) {
					System.out.print("Ngày sinh: ");
					ngaySinh[i] = scan3.nextLine();

					lap = 0;
					try {
						kiemtra.checkNgaySinh(ngaySinh[i]);
					} catch (XuLiNgoaiLe e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
						lap = 1;
					}

				}

				lap = 1;
				while (lap == 1) {

					System.out.print("Email: ");
					email[i] = scan3.nextLine();
					lap = 0;
					try {
						kiemtra.checkEmail(email[i]);
					} catch (XuLiNgoaiLe e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
						lap = 1;
					}

				}

				lap = 1;

				while (lap == 1) {

					System.out.print("Số điện thoại: ");
					soDienThoai[i] = scan3.nextLine();
					lap = 0;
					try {
						kiemtra.checkSDT(soDienThoai[i]);
					} catch (XuLiNgoaiLe e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
						lap = 1;
					}

				}

				System.out.print("địa chỉ: ");
				diaChi[i] = scan3.nextLine();

				i += 1;
			}

			// Tạo chuỗi để ghi lên tệp

			i = 0;
			while (i < n) {
				s = s + "#" + maSo[i] + "$" + tenHV[i] + "$" + ngaySinh[i] + "$" + email[i] + "$" + soDienThoai[i] + "$"
						+ diaChi[i] + "$";
				i += 1;
			}

			// Ghi danh sách học viên vừa nhập lên tệp
			try {
				FileWriter fileWriter = new FileWriter("C:/QUANLIHOCVIEN.txt");

				fileWriter.write(s);

				fileWriter.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("ĐÃ CẬP NHẬP THÔNG TIN THÀNH CÔNG !!!");

			break;
		case "1":
			String tuKhoa = "";
			System.out.print("Vui lòng nhập mã số học viên cần thay đổi: #");
			tuKhoa = scan3.nextLine();
			int x;
			x = Integer.parseInt(tuKhoa);
			tuKhoa = "#" + tuKhoa;
			
			
			int find = s.indexOf(tuKhoa);
			if (find == -1) {
				System.out.println("Không tìm thấy mã số học viên cần thay đổi");
			} else {
				int soKiTu$ = 0;
				String s1 = s.substring(0, find);

				StringBuilder chuoi = new StringBuilder();
				while (soKiTu$ < 6) {
					if (s.charAt(find) != '$') {
						chuoi = chuoi.append(s.charAt(find));
						find = find + 1;
					} else {
						find = find + 1;
						soKiTu$ += 1;
					}

				}
				String s2 = s.substring(find);

				System.out.println("Nhập lại thông tin cần thay đổi cho học viên có mã số " + tuKhoa + ":");
				String maSo = tuKhoa;
				System.out.print("\nTên học viên: ");
				String tenHV = scan3.nextLine();

				KiemTraNgoaiLe kiemtra2 = new KiemTraNgoaiLe();
				int lap = 1;
				
				ngaySinh = new String[1000];
				email = new String[1000];
				soDienThoai = new String[1000];
				diaChi = new String[1000];
				while (lap == 1) {
					System.out.print("Ngày sinh: ");
					ngaySinh[x] = scan3.nextLine();

					lap = 0;
					try {
						kiemtra2.checkNgaySinh(ngaySinh[x]);
					} catch (XuLiNgoaiLe e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
						lap = 1;
					}

				}

				lap = 1;
				while (lap == 1) {

					System.out.print("Email: ");
					email[x] = scan3.nextLine();
					lap = 0;
					try {
						kiemtra2.checkEmail(email[x]);
					} catch (XuLiNgoaiLe e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
						lap = 1;
					}

				}

				lap = 1;

				while (lap == 1) {

					System.out.print("Số điện thoại: ");
					soDienThoai[x] = scan3.nextLine();
					lap = 0;
					try {
						kiemtra2.checkSDT(soDienThoai[x]);
					} catch (XuLiNgoaiLe e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
						lap = 1;
					}

				}

				System.out.print("địa chỉ: ");
				String diaChi = scan3.nextLine();

				s = s1 + maSo + "$" + tenHV + "$" + ngaySinh[x] + "$" + email[x] + "$" + soDienThoai[x] + "$" + diaChi + "$"
						+ s2;
				try {
					FileWriter fileWriter = new FileWriter("C:/QUANLIHOCVIEN.txt");

					fileWriter.write(s);

					fileWriter.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("ĐÃ CẬP NHẬP THÔNG TIN THÀNH CÔNG !!!");
			}

			break;
		default:
			System.out.println("Bạn đã nhập không đúng chức năng của ứng dụng !!!");
			break;
		}

	}

}

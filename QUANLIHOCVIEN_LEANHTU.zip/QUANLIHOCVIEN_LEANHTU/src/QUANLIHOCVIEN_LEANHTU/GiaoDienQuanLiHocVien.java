package QUANLIHOCVIEN_LEANHTU;

import java.util.*;

public class GiaoDienQuanLiHocVien {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		ChucNangQuanLiHocVien chucNang = new ChucNangQuanLiHocVien();
		System.out.println("\tỨNG DỤNG QUẢN LÍ HỌC VIÊN (v1.0)");
		System.out.println("\t=========================");
		System.out.println("<0>: XEM DANH SÁCH HỌC VIÊN ");
		System.out.println("<1>: TẠO DANH SÁCH HỌC VIÊN MỚI ");
		System.out.println("<2>: CẬP NHẬT DANH SÁCH HỌC VIÊN ");
		System.out.println("<3>: TÌM KIẾM HỌC VIÊN ");
		System.out.println("<4>: XOÁ THÔNG TIN HỌC VIÊN ");
		System.out.println("<5>: XEM MENU VÀ THÔNG TIN ỨNG DỤNG ");
		System.out.println("<6>: THOÁT ỨNG DỤNG !!!");
		while (true) {

			System.out.println("\t=========================");
			System.out.print("\tMỜI BẠN NHẬP CHỨC NĂNG: ");
			String s = scan.nextLine();
			System.out.println("\t=========================");
			switch (s) {
			case "0":
				System.out.println("\tXEM DANH SÁCH HỌC VIÊN ");
				chucNang.xemHocVien();
				break;
			case "1":
				System.out.println("\tTẠO DANH SÁCH HỌC VIÊN MỚI ");
				chucNang.themHocVien();
				break;
			case "2":
				System.out.println("\tCẬP NHẬT THÔNG TIN HỌC VIÊN ");
				chucNang.capNhat();
				break;
			case "3":
				System.out.println("\tTÌM KIẾM HỌC VIÊN ");
				chucNang.timKiem();
				break;
			case "4":
				System.out.println("\tXOÁ THÔNG TIN HỌC VIÊN ");
				chucNang.xoaHocVien();
				break;
			case "5":
				System.out.println("\t _______________________________________");
				System.out.println("\t|<0>: XEM DANH SÁCH HỌC VIÊN \t\t| ");
				System.out.println("\t|<1>: TẠO DANH SÁCH HỌC VIÊN MỚI \t| ");
				System.out.println("\t|<2>: CẬP NHẬT DANH SÁCH HỌC VIÊN \t| ");
				System.out.println("\t|<3>: TÌM KIẾM HỌC VIÊN \t\t| ");
				System.out.println("\t|<4>: XOÁ THÔNG TIN HỌC VIÊN \t\t| ");
				System.out.println("\t|<5>: XEM MENU VÀ THÔNG TIN ỨNG DỤNG \t| ");
				System.out.println("\t|<6>: THOÁT ỨNG DỤNG !!! \t\t| ");
				System.out.println("\t _______________________________________");

				System.out.println(
						"\n ỨNG DỤNG QUẢN LÍ HỌC VIÊN ĐƯỢC XÂY DỰNG BẰNG NGÔN NGỮ LẬP TRÌNH JAVA, PHÁT TRIỂN BỞI HỌC VIÊN LÊ ANH TÚ - KHOÁ AK221 - LỚP LẬP TRÌNH ANDROID - TTTH ĐH KHOA HỌC TỰ NHIÊN");
				break;
			case "6":
				System.out.println("\tTHOÁT ỨNG DỤNG THÀNH CÔNG!!!");
				while (true) {
					int ketthuc = 0;
				}

			default:
				System.out.println("BẠN ĐÃ NHẬP KHÔNG ĐÚNG CHỨC NĂNG CỦA ỨNG DỤNG, VUI LÒNG NHẬP LẠI !!!");
				break;
			}

		}

	}
}

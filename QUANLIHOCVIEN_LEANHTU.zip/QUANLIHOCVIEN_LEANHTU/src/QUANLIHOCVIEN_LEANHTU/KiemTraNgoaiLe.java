package QUANLIHOCVIEN_LEANHTU;

import java.util.Scanner;

public class KiemTraNgoaiLe {

	public static void checkSDT(String str) throws XuLiNgoaiLe {
		String sdtHopLe = "(\\+84|0)\\d{9,10}";
		Boolean b = str.matches(sdtHopLe);
		if (b == false)
			throw new XuLiNgoaiLe("Số điện thoại không hợp lệ, mời nhập lại cho đúng !!!");
	}

	public static void checkEmail(String str) throws XuLiNgoaiLe {
		String emailHopLe = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		Boolean b = str.matches(emailHopLe);
		if (b == false)
			throw new XuLiNgoaiLe("Email không hợp lệ, mời nhập lại cho đúng !!!");
	}

	public static void checkNgaySinh(String str) throws XuLiNgoaiLe {
		String ngaySinhHopLe = "(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)";
		Boolean b = str.matches(ngaySinhHopLe);
		if (b == false)
			throw new XuLiNgoaiLe("Ngày sinh không hợp lệ, mời nhập lại cho đúng !!!");
	}

}
